import json
import boto3
import logging
import os
import sys
from datetime import datetime
from urllib.parse import unquote

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    Simplified AWS Lambda handler focusing on document management
    """
    try:
        # Get HTTP method and path
        http_method = event.get('httpMethod', 'POST')
        path = event.get('path', '/')
        
        logger.info(f"🔍 Processing {http_method} request to {path}")
        logger.info(f"📋 Event: {json.dumps(event, default=str)[:500]}...")
        
        # Common headers for all responses
        headers = {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        }
        
        # Handle OPTIONS requests for CORS
        if http_method == 'OPTIONS':
            logger.info("✅ Handling OPTIONS request")
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'message': 'CORS preflight'})
            }
        
        # Route requests based on path and method
        if path.startswith('/documents'):
            logger.info("📄 Routing to document handler")
            return handle_document_request_simple(event, context, headers)
        else:
            logger.info("💬 Routing to default handler")
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'message': 'Default handler - documents endpoint available at /documents/{knowledgeBaseId}/{dataSourceId}'})
            }
            
    except Exception as e:
        logger.error(f"❌ Request processing failed: {str(e)}")
        logger.error(f"❌ Error type: {type(e).__name__}")
        import traceback
        logger.error(f"❌ Traceback: {traceback.format_exc()}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': str(e),
                'error_type': type(e).__name__
            })
        }


def handle_document_request_simple(event, context, headers):
    """
    Simplified document management handler
    """
    try:
        http_method = event.get('httpMethod')
        path = event.get('path', '')
        
        logger.info(f"🔍 Processing document request: {http_method} {path}")
        
        # Parse path to extract parameters
        path_parts = [p for p in path.split('/') if p]
        logger.info(f"📂 Path parts: {path_parts}")
        
        if len(path_parts) < 3:
            logger.error(f"❌ Invalid path: {path}")
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'error': 'Invalid path. Expected format: /documents/{knowledgeBaseId}/{dataSourceId}',
                    'received_path': path,
                    'path_parts': path_parts
                })
            }
        
        knowledge_base_id = unquote(path_parts[1])
        data_source_id = unquote(path_parts[2])
        
        logger.info(f"🎯 KB: {knowledge_base_id}, DS: {data_source_id}")
        
        if http_method == 'GET':
            # List documents using direct S3 approach
            logger.info(f"📄 Listing documents for KB: {knowledge_base_id}, DS: {data_source_id}")
            
            try:
                # Initialize S3 and Bedrock clients
                s3_client = boto3.client('s3', region_name='eu-west-1')
                bedrock_agent_client = boto3.client('bedrock-agent', region_name='eu-west-1')
                
                logger.info("✅ AWS clients initialized")
                
                # Get data source configuration
                logger.info("🔍 Getting data source configuration...")
                response = bedrock_agent_client.get_data_source(
                    knowledgeBaseId=knowledge_base_id,
                    dataSourceId=data_source_id
                )
                
                data_source = response.get('dataSource', {})
                s3_config = data_source.get('dataSourceConfiguration', {}).get('s3Configuration', {})
                
                bucket_arn = s3_config.get('bucketArn', '')
                inclusion_prefixes = s3_config.get('inclusionPrefixes', [''])
                
                # Extract bucket name from ARN
                bucket_name = bucket_arn.split(':::')[-1] if bucket_arn else None
                
                logger.info(f"📦 Bucket: {bucket_name}, Prefixes: {inclusion_prefixes}")
                
                if not bucket_name:
                    logger.error("❌ No bucket name found in data source configuration")
                    return {
                        'statusCode': 500,
                        'headers': headers,
                        'body': json.dumps({
                            'error': 'No bucket name found in data source configuration',
                            'data_source_config': s3_config
                        })
                    }
                
                documents = []
                
                # List objects for each prefix
                for prefix in inclusion_prefixes:
                    try:
                        logger.info(f"🔍 Listing objects with prefix: {prefix}")
                        paginator = s3_client.get_paginator('list_objects_v2')
                        pages = paginator.paginate(
                            Bucket=bucket_name,
                            Prefix=prefix,
                            MaxKeys=100  # Limit for testing
                        )
                        
                        for page in pages:
                            if 'Contents' in page:
                                for obj in page['Contents']:
                                    key = obj['Key']
                                    
                                    # Skip folders
                                    if key.endswith('/'):
                                        continue
                                    
                                    # Get file extension
                                    file_ext = os.path.splitext(key)[1].lower()
                                    allowed_extensions = {
                                        '.pdf': 'application/pdf',
                                        '.doc': 'application/msword',
                                        '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                                        '.txt': 'text/plain'
                                    }
                                    
                                    if file_ext not in allowed_extensions:
                                        continue
                                    
                                    # Extract filename from key
                                    filename = os.path.basename(key)
                                    
                                    document = {
                                        'id': key,
                                        'name': filename,
                                        'status': 'ACTIVE',
                                        'createdAt': obj['LastModified'].isoformat(),
                                        'updatedAt': obj['LastModified'].isoformat(),
                                        'size': obj['Size'],
                                        'type': allowed_extensions[file_ext],
                                        'metadata': {
                                            's3Key': key,
                                            's3Bucket': bucket_name,
                                            'etag': obj['ETag'].strip('"')
                                        }
                                    }
                                    
                                    documents.append(document)
                                    
                    except Exception as e:
                        logger.error(f"❌ Error listing objects with prefix {prefix}: {str(e)}")
                        continue
                
                logger.info(f"✅ Found {len(documents)} documents")
                
                response_body = {
                    'documents': documents,
                    'knowledge_base_id': knowledge_base_id,
                    'data_source_id': data_source_id,
                    'count': len(documents),
                    'timestamp': datetime.now().isoformat()
                }
                
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps(response_body)
                }
                
            except Exception as list_error:
                logger.error(f"❌ Error in document listing: {str(list_error)}")
                import traceback
                logger.error(f"❌ Traceback: {traceback.format_exc()}")
                return {
                    'statusCode': 500,
                    'headers': headers,
                    'body': json.dumps({
                        'error': f'Error listing documents: {str(list_error)}',
                        'error_type': type(list_error).__name__,
                        'knowledge_base_id': knowledge_base_id,
                        'data_source_id': data_source_id
                    })
                }
        else:
            return {
                'statusCode': 405,
                'headers': headers,
                'body': json.dumps({'error': f'Method {http_method} not implemented yet'})
            }
            
    except Exception as e:
        logger.error(f"❌ Document request processing failed: {str(e)}")
        import traceback
        logger.error(f"❌ Traceback: {traceback.format_exc()}")
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': str(e),
                'error_type': type(e).__name__
            })
        }
